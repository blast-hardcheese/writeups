#! /usr/bin/python

import sqlite3
import display_score
import display_quest
from cgi import escape
import config

cdb = sqlite3.connect(config.PATH_TO_DB)
cc=cdb.cursor()
cc.execute("""
    select rowid, challenge_name, tags, point_value,
    case when answer_hash in (select answer_hash from team_score) then 1 else 0 end,
    open from questions""")
questionlist = cc.fetchall()

cc.execute("""
    select team_name, sum(questions.point_value) as total
    from team_score join questions
    on team_score.challenge_name = questions.challenge_name
    and team_score.answer_hash = questions.answer_hash
    group by team_name
    order by total desc""")
scorelist = cc.fetchall()

print """<HTML><HEAD><META HTTP-EQUIV=\"REFRESH\" CONTENT=\"60\"><TITLE>OCTF SCOREBOARD</TITLE>
<style type='text/css'>
table {
    font-size: 24;
    font-family: monospace;
}
</style>
</HEAD><BODY><img src='vand.png' style="display:inline-block;"/><span style="font-size:12em;vertical-align:top;">OpenCTF </span><img src='dc562.png' style="display:inline-block;"/><br/>
<br/><TABLE BORDER=\"0\" CELLPADDING=\"10\"><TR><TD VALIGN=\"TOP\"><TT>"""
print escape(display_score.scoretable(scorelist)).replace("\r\n","\r\n<BR/>").replace(" ","&nbsp;")
print "</TT></TD><TD VALIGN=\"TOP\"><TT>"
print escape(display_quest.questiontable(questionlist)).replace("\r\n","\r\n<BR/>").replace(" ","&nbsp;")
print "</TT></TD></TR></TABLE></BODY></HTML>"

