from time import strftime

def scoretable(teams):
    header = [
        'Rank',
        'Team Name',
        'Points'
    ]
    as_str = [(str(i+1),team,str(points)) for i,(team,points) in enumerate(teams)]
    max_len = [max(len(r[i]) for r in ([header]+as_str)) for i in xrange(len(header))]
    col_width = [l+2 for l in max_len]
    centered_str = [
            (
                r[0].rjust(col_width[0]-1)+' ',
                ' ' + r[1].ljust(col_width[1]-1),
                r[2].rjust(col_width[2]-1)+' ',
            )
            for r in as_str
    ]

    row_sep = "+".join('-'*w for w in [0]+col_width+[0])

    timedata = strftime('%d-%b-%y %H:%M:%S --- SCOREBOARD')
    result_rows = [
            timedata.center(len(row_sep)),
            row_sep,
            '|'+('|'.join(h.center(w) for h,w in zip(header,col_width)))+'|',
            row_sep
    ] + ['|'+('|'.join(row))+'|' for row in centered_str] + [
        row_sep
    ]

    return '\r\n'.join(result_rows)

