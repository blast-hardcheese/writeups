#!/usr/bin/python

import sqlite3, display_score, display_quest, time, socket, syslog, getpass
from sys import exit
from hashlib import sha512
import config
import sys

def syslog(message):
    level=7
    facility=3
    host='172.31.2.3'
    port=514
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    data = '<%d>%s' % (level + facility*8, message)
    sock.sendto(data, (host, port))
    sock.close()

def team_score(teamname):
    cc.execute("""
        select sum(questions.point_value)
            from team_score join questions
            on team_score.answer_hash = questions.answer_hash
            and team_score.challenge_name = questions.challenge_name
            where team_name=?""",
        [teamname])
    val = cc.fetchone()[0]
    return val or 0

def delay(n):
    time.sleep(1)
    for i in xrange(n):
        sys.stdout.write('.');
        sys.stdout.flush()
        time.sleep(1)
    sys.stdout.write("\r"+(" "*n)+"\r")
    sys.stdout.flush()

def print_qual_message(teamname):
    print ""
    print ""
    print ""
    delay(4)
    print "Congratulations, %s." % teamname
    delay(2)
    print "You have demonstrated your skills. You are now ready for. . . the truth."
    delay(2)
    print "But first, you must make a choice:"
    delay(2)
    print ""
    print "\tTake the blue pill, and you'll be returned to safety. All records of your involvement with our cause will be scrubbed, and any incriminating memories will be removed"
    delay(3)
    print "\tTake the red pill, and you'll see just how deep our network goes"
    delay(3)
    print "\tTake the purple pill, and, we'll come back next year with a sequel or two. And it will be all your fault."
    delay(5)
    print """
    .-.       .-.       .-.   
   /:::\     /:::\     /:::\  
  /::::/    /::::/    /::::/  
 / `_:/    / `_:/    / `_:/   
/    /    /    /    /    /    
\   /     \   /     \   /     
 `"`       `"`       `"`      """
    delay(3)
    print "which pill would you like? 1, 2, or 3?"
    delay(6)
    print ""
    print "lol j/k. you're in. now solve some more challenges!"
    print ""
    print "[press enter to continue]"
    raw_input("")
    print """
* g o a t s e x * g o a t s e x * g o a t s e x *
g                                               g
o /     \             \            /    \       o
a|       |             \          |      |      a
t|       `.             |         |       :     t
s`        |             |        \|       |     s
e \       | /       /  \\\   --__ \\       :    e
x  \      \/   _--~~          ~--__| \     |    x
*   \      \_-~                    ~-_\    |    *
g    \_     \        _.--------.______\|   |    g
o      \     \______// _ ___ _ (_(__>  \   |    o
a       \   .  C ___)  ______ (_(____>  |  /    a
t       /\ |   C ____)/      \ (_____>  |_/     t
s      / /\|   C_____)       |  (___>   /  \    s
e     |   (   _C_____)\______/  // _/ /     \   e
x     |    \  |__   \\_________// (__/       |  x
*    | \    \____)   `----   --'             |  *
g    |  \_          ___\       /_          _/ | g
o   |              /    |     |  \            | o
a   |             |    /       \  \           | a
t   |          / /    |         |  \           |t
s   |         / /      \__/\___/    |          |s
e  |           /        |    |       |         |e
x  |          |         |    |       |         |x
* g o a t s e x * g o a t s e x * g o a t s e x *
"""
    print "lol j/k again. your in this time. now solve some more challenges!"
    print ""

def print_questions_list(teamname, current_score):
    if current_score >= config.QUALIFICATION_SCORE:
        cc.execute("""
            select rowid, challenge_name, tags, point_value,
            case when answer_hash in (select answer_hash from team_score where team_name=(?) and team_score.challenge_name=questions.challenge_name) then 1 else 0 end,
            open from questions""", [teamname])
    else:
        cc.execute("""
            select rowid, challenge_name, tags, point_value,
            case when answer_hash in (select answer_hash from team_score where team_name=(?) and team_score.challenge_name=questions.challenge_name) then 1 else 0 end,
            open from questions where qualification=1""", [teamname])
    questionlist = cc.fetchall()
    print "\r\n"*50
    print display_quest.questiontable(questionlist)

    #print lead questions/round score
    if current_score < config.QUALIFICATION_SCORE:
        print "(%d/%d) points needed for full scoreboard" % (current_score, config.QUALIFICATION_SCORE)
    else:
        cc.execute("""
            select rowid, challenge_name, tags, point_value, solved, open
            from questions where solved=0 and open=1""")
        leadquest = cc.fetchall()
        if len(leadquest) > 0:
            for x in leadquest:
                print "LEAD QUESTION --- "+str(x[0])+" - "+x[1]+' '+str(x[3])
        else:
            print "no leading questions - call an adult"

def display_leaderboard():
    cc.execute("""
        select team_name, sum(questions.point_value) as total
        from team_score join questions
        on team_score.challenge_name = questions.challenge_name
        and team_score.answer_hash = questions.answer_hash
        group by team_name
        order by total desc""")
    scorelist = cc.fetchall()
    print display_score.scoretable(scorelist)
    null = raw_input("[pause]")

def open_question(player_input):
    #actually get the question
    try:
        question_to_open = int(player_input)
    except:
        raw_input("invalid question number")
        return None
    cc.execute("""
        select challenge_name, point_value, question,
        case when answer_hash in (select answer_hash from team_score where team_name=(?) and team_score.challenge_name = questions.challenge_name) then 1 else 0 end,
        open, tags from questions
        where rowid=?""",[teamname, question_to_open])
    try:
        challenge_name, point_value, question, solved, is_open, tags = cc.fetchone()
    except:
        raw_input("ERROR --- COULD NOT OPEN QUESTION")
        return None
    #is the question open?
    if is_open == 0:
        raw_input("ERROR --- QUESTION NOT OPEN")
        return None
    #print the question
    print '\n',challenge_name,point_value,'---\n',question,'\n'
    #have they already solved it
    if solved == 1:
        raw_input("BUT --- YOU'VE ALREADY SOLVED IT")
        return None
    return (question_to_open, challenge_name, point_value, question, tags)

def answer_question(teamname, question_id, challenge_name, point_value, question):
    #answer the question
    player_input=raw_input("'enter' to return, or Answer: ").strip()
    if player_input == '':
        return None

    #connect to server
    #try:
    syslog('%SCOREBOARD-SUBMIT '+challenge_name+' '+str(point_value)+' : '+teamname+' : '+player_input)
    #except:
        #print 'error in logging'
    digest = sha512(player_input).hexdigest()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("127.0.0.1",41337))
    except:
        print "scoreboard connection blown up --- call an adult"
        time.sleep(1)
        return None
    sdata = s.recv(32)
    if sdata != "lol goatse":
        #failed to connect properly (?)
        s.close()
        return None

    #submit the answer
    s.sendall(",".join( [teamname, str(question_id), digest] ))
    sdata = s.recv(32)
    return (s,sdata)

def unlock_new_question(server, solved_tags):
    cc.execute('select rowid,challenge_name,tags,point_value,0,open from questions where open = 0')
    #limit by tags
    new_tags = lambda row: len(set(row[2].split()).intersection(set(solved_tags.split()[1:]))) == 0
    legal_to_open = filter(new_tags, cc.fetchall())
    legal_ids = [r[0] for r in legal_to_open]
    if len(legal_to_open) == 0:
        print
        print "YOU HAVE JUST LOST THE GAME"
        raw_input("[pause]")
        return None

    print
    print "\r\n"*50
    print "You have qualified to choose the next lead question."
    raw_input("")
    print "LEGAL QUESTIONS TO OPEN:"
    print display_quest.questiontable(legal_to_open)
    question_to_open = None
    while True:
        try:
            question_to_open = int(raw_input("Choose a question number to unlock: "))
            if question_to_open in legal_ids:
                break
            else:
                print "not a legal choice"
        except:
            continue

    server.sendall(str(question_to_open))
    server.close()


print '\r\n'*50
try:
    #teamname = raw_input("Team Name: ")
    teamname = getpass.getuser()
    teamname = teamname.strip()[:32]
    if not teamname:
        exit()
except:
    print "no team name selected"
    exit()

cdb = sqlite3.connect(config.PATH_TO_DB)
cc=cdb.cursor()

while teamname != [""]:
    #try
    time.sleep(.2)
    current_score = team_score(teamname)
    print_questions_list(teamname, current_score)
    print current_score
    player_input = raw_input("pick a question number, 'enter' for leaderboard, or 'q' to quit : ").strip()
    if player_input == '':
        display_leaderboard()
        continue
    if player_input == 'q':
        break
    resp = open_question(player_input)
    if resp is None:
        continue
    qid, challenge_name, point_value, question, tags = resp
    r = answer_question(teamname, qid, challenge_name, point_value, question)
    if r is None:
        continue
    server, response = r

    if response == "wrong":
       raw_input("WRONG!!!")
    if response in ["correct", "correct_and_first"]:
        raw_input("CORRECT!!!")
        new_score = team_score(teamname)
        if new_score >= config.QUALIFICATION_SCORE and current_score < config.QUALIFICATION_SCORE:
            print_qual_message(teamname)
        current_score = new_score
    if response == "correct_and_first" and current_score >= config.QUALIFICATION_SCORE:
        unlock_new_question(server, tags)
    if response not in ["wrong", "correct", "correct_and_first"]:
        raw_input("unexpected scoreboard response...")
    server.close()
    #except:
    #    print "goodbye"
    #    break
