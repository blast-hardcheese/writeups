#!/usr/bin/python

from time import strftime

def questiontable(questions):
    header = ['No.','Challenge','Author', 'Tags','Point Value','Solved','Open']
    as_str = [
            (
                str(q[0]), q[1],
                q[2].split()[0], ','.join(q[2].split()[1:]),
                str(q[3]),
                'YES' if q[4] == 1 else 'NO',
                'YES' if q[5] == 1 else 'NO'
            )
            for q in questions
    ]
    max_len = [max(len(r[i]) for r in ([header]+as_str)) for i in xrange(len(header))]
    col_width = [l+2 for l in max_len]
    centered_str = [
        (
            q[0].rjust(col_width[0]-1)+' ',
            ' '+q[1].ljust(col_width[1]-1),
            ' '+q[2].ljust(col_width[2]-1),
            ' '+q[3].ljust(col_width[3]-1),
            q[4].center(col_width[4]),
            q[5].center(col_width[5]),
            q[6].center(col_width[6])
        )
        for q in as_str
    ]

    row_sep = "+".join('-'*w for w in [0]+col_width+[0])

    timedata = strftime('%d-%b-%y %H:%M:%S --- QUESTION LIST')
    result_rows = [
            timedata.center(len(row_sep)),
            row_sep,
            '|'+('|'.join(h.center(w) for h,w in zip(header,col_width)))+'|',
            row_sep
    ] + ['|'+('|'.join(row))+'|' for row in centered_str] + [
        row_sep
    ]

    return '\r\n'.join(result_rows)
