#!/usr/bin/python

from socket import *
import thread, sqlite3, base64, time
import config

BUFF = 1024
HOST = '127.0.0.1'# must be input parameter @TODO
PORT = 41337 # must be input parameter @TODO

def handler(clientsock,addr):
    while 1:
        clientsock.sendall("lol goatse")
        data = clientsock.recv(BUFF)
        print "got ",data
        data = data.strip().split(',')
        if not data[2]:
            break
        print "2"
        anstime = time.strftime('%Y-%d-%m %H:%M:%S')
        team_name, question_id, submitted_hash = data
        question_id = int(question_id)
        db = sqlite3.connect(config.PATH_TO_DB)
        dbc = db.cursor()
        dbc.execute('select challenge_name,point_value,answer_hash,solved from questions where rowid=(?)', [question_id])
        challenge_name, point_value, correct_hash, already_solved = dbc.fetchone()
        print challenge_name, point_value, correct_hash, already_solved
        if team_name == "openctf":
            if submitted_hash == correct_hash:
                clientsock.sendall("correct")
            else:
                clientsock.sendall("wrong")
            db.close()
            break



        dbc.execute('select count(rowid) from questions where open=1 and solved=0')
        lead_questions_exist = dbc.fetchone()[0] > 0
        was_first = int( (not lead_questions_exist) or (not already_solved) )
        if submitted_hash == correct_hash:
            response = ["correct", "correct_and_first"][was_first]
            dbc.execute('update questions set solved=1 where rowid=(?)',[question_id])
        else:
            response = "wrong"
        print (team_name, question_id, challenge_name, point_value, response, was_first)
        print "%s attempted to solve %d. %s for %d. they were %s and %d" % (team_name, question_id, challenge_name, point_value, response, was_first)
        values = (team_name, challenge_name, point_value, submitted_hash, anstime, was_first)
        dbc.execute('insert into team_score values(?,?,?,?,?,?)', values)
        db.commit()
        clientsock.sendall(response)
        if response == "correct_and_first":
            to_open = clientsock.recv(BUFF)
            to_open = to_open.strip()[:2]
            dbc.execute('update questions set open=1 where rowid=(?)',[to_open])
            db.commit()
            print team_name,'opened question ',to_open
        db.close()
        break

if __name__=='__main__':
    ADDR = (HOST, PORT)
    serversock = socket(AF_INET, SOCK_STREAM)
    serversock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    serversock.bind(ADDR)
    serversock.listen(5)
    while 1:
        print 'waiting for connection... listening on port', PORT
        clientsock, addr = serversock.accept()
        print '...connected from:', addr
        thread.start_new_thread(handler, (clientsock, addr))



