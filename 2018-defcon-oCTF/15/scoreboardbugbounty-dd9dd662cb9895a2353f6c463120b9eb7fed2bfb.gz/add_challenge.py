#! /usr/bin/python

import sqlite3
import time
from hashlib import sha512

qt = sqlite3.connect('central.db')
qc = qt.cursor()
hq=[]
questions = [
        ('kajers-challenge','stego-tag',100,'this is the answer','this is the question',1,1,1),
        ('drifters-challenge','network',100,'this is the other 100 point answer','this is the other 100 point question',1,1,1),
        ('yens-challenge','pwnable',100,'omg 100 points','100 point question',0,0,0),
        ('drifter2','network',200,'this is an answer','question text...',0,1,0),
        ('Scoreboard Bug Bounty','MIC DROP',500,'this_is_not_the_flag','Solve This to 0wn the scoreboard',0,0,0),
        ]

for row in questions:
   hq += [(row[0],row[1],row[2],sha512(row[3]).hexdigest(),row[4],row[5],row[6],row[7])]

for row in hq:
   qc.execute('insert into questions values (?,?,?,?,?,?,?,?)', row)

qt.commit()
qc.close()
